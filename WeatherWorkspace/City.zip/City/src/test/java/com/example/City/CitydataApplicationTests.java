package com.example.City;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitydataApplicationTests {

	@Test
	void contextLoads() {
	}

}
