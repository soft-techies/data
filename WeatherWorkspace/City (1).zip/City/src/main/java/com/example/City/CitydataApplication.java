package com.example.City;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CitydataApplication {

	public static void main(String[] args) {
		SpringApplication.run(CitydataApplication.class, args);
	}

}
